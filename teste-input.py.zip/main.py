# Solicita nome e idade do usuário
nome = input("Digite seu nome: ")
idade = input("Digite sua idade: ")

# Converte a idade para um inteiro
idade = int(idade)

print(f"Olá {nome}, você tem {idade} anos.")
